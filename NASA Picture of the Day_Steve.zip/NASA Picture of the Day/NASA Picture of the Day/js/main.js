// i need to obtain a NASA api to pull images from
//I need to provide the user with the option to select specific dates
// Individual pictures should display for each date option
// Request data from NASA
// Build the URL
// Data is received
// Display image

function getPic(){
  var APIKey = "LgHtmJi3y6HVxcpetXq21RlMZOTcMtxj3FZMRgXH";
  var userDate = $("#setDate").val();
  var nasaURL = "https://api.nasa.gov/planetary/apod?api_key=";
  var fullURL = nasaURL + APIKey + "&date=" + userDate;
  console.log(fullURL)
  $.ajax({
    url: fullURL,
    success: function(result){
      $(".picoftheday").append( "<img src=" + result.url +">")
      //data is retrieved successfully
      }
  });
}













// var numsArray = [];
// var total = 0;
//
// function beautiful(multiple1,multiple2,upwardBound){
//   	for(var n=0;n<=upwardBound;n++){
// 		if (n % multiple1 === 0 || n % multiple2 === 0){
// 			numsArray.push(n);
//   	}
// 	}
//   sum(numsArray);
// }
//
// 	function sum(multiArr){
// 		multiArr.forEach(function(a){
//       total += a;
//     });
//    console.log(total);
//   }
//
// beautiful(3,5,1000);
